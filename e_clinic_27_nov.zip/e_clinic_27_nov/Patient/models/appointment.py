from Patient.models.patient import MstPatient
from CustomAuth.models import User, ProfessionalType
from django.db import models
from Staff.models.doctor import TblDoctorSchedule, TblDoctorSlot
from django.contrib.auth.models import Group
from Staff.models.professional_Onboarding import HealthProfessionalPersonalDetails


class Appointment(models.Model):
    appointment_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.RESTRICT, default=User)
    patient = models.ForeignKey(MstPatient, on_delete=models.RESTRICT)
    date = models.DateField()
    time = models.TimeField()
    professional_Type = models.ForeignKey(ProfessionalType, on_delete=models.RESTRICT)
    doctor = models.ForeignKey(HealthProfessionalPersonalDetails, on_delete=models.RESTRICT)
    slot = models.ForeignKey(TblDoctorSlot, on_delete=models.RESTRICT)
    active = models.BooleanField(default=True)
    created_by = models.CharField(max_length=30)
    updated_by = models.CharField(max_length=30)
    create_date = models.DateField(auto_now_add=True)
    update_date = models.DateField(auto_now=True)
