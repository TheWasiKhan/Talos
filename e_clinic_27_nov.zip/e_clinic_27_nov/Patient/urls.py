from django.urls import path
from Patient.views import manage_patient, manage_appointments
from Staff.views import manage_doctor

urlpatterns = [
    path('', manage_patient.index, name='Patient'),
    path('patient-registration/', manage_patient.patient_registration, name='patient_registration'),
    path('edit_patient_details/', manage_patient.edit_patient_details, name='edit_patient_details'),
    path('book-appointments/', manage_appointments.book_appointments, name='book_appointments'),
    path('book_appointment_for/<int:record_id>/', manage_appointments.book_appointment, name='book_appointment_for'),
]
