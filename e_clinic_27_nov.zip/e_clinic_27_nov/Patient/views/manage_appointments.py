from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

from Patient.models.patient import MstPatient
from Staff.decorators import allowed_group_users, unauthenticated_user
from Staff.models.professional_Onboarding import HealthProfessionalPersonalDetails


def book_appointment(request, record_id):
    if request.user.is_authenticated:
        patient = MstPatient.get_all_patients()
        selected_patient = MstPatient.get_patient_by_id(record_id)
        doctor_list = HealthProfessionalPersonalDetails.get_doctors_list()
        if request.method == 'POST':
            pass

        else:
            return render(request, 'book_appointment.html', {'patient': patient, 'selected_patient': selected_patient, 'doctor_list': doctor_list})
    else:
        return redirect('account_login')


def select_doctor(request, doctor_id):
    if request.user.is_authenticated:
        selected_doctor = HealthProfessionalPersonalDetails.get_doctor(doctor_id)
        print("selected_doctor: ", selected_doctor)
    else:
        return redirect('account_login')


def book_appointments(request):
    if request.user.is_authenticated:
        patient = MstPatient.get_all_patients()
        doctor_list = HealthProfessionalPersonalDetails.get_doctors_list()
        return render(request, 'book_appointment.html',
                      {'patient': patient, 'doctor_list': doctor_list})
    else:
        return redirect('account_login')
