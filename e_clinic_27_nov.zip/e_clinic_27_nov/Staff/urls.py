from django.urls import path
from Staff.views import manage_admin, manage_doctor, manage_slots
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', manage_doctor.homepage, name='homepage'),
    path('user/admin/dashboard', manage_admin.admin_dashboard, name='admin_dashboard'),
    path('Doctor/', manage_doctor.doctor_dashboard, name='Doctor'),
    path('Slot/', manage_slots.manage_slot, name='Slot'),
    path('FrontDesk/', manage_doctor.med_prof_onboarding, name='FrontDesk'),
    path('Doctor/consultation/', manage_doctor.doctor_consultation, name='doctor-consultation'),
    path('Doctor/speech-to-text/', manage_doctor.speech_to_text, name='speech-to-text'),
    # path('transcribe_audio', manage_doctor.transcribe_audio, name='transcribe_audio'),
    path('Medical-Professional-Onboarding/', manage_doctor.med_prof_onboarding, name='Medical-Professional-Onboarding'),
]
