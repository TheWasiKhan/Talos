from django.contrib.auth.hashers import make_password
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required
from CustomAuth.models import ProfessionalType, User


def homepage(request):
    po = ProfessionalType(name='Admin')
    # po.save()

    p = ProfessionalType.objects.get(id=1)


    print("p------------", p)
    print("p.name GET------------", p.name)

    q = ProfessionalType.objects.all()
    # value = {'data': q,
    #          'data1': p}
    print("q===", q)
    for i in q:
        print("q.name Filter===", i.name)

    phone = 7400330074
    pa = 'adminadmin'
    password = make_password(pa)
    email = 'admin@dnits.com'

    # user = User(profession=p, phone=phone, password=password, email=email, is_superuser=True, is_staff=True)
    # user.save()

    # user.password=password
    # user.save()
    # group = Group.objects.get(name='Staff')
    # new_user = User.objects.filter()
    # new_user.groups.add(group)
    # object = request.user.profession.name
    # group = request.user.professional_type.name
    # group = request.user.groups.name
    # group = request.user.groups.values_list('name')
    # group = request.user.groups.all()
    # group = request.user.groups.all()[0].name

    # get() --- single record -- fetch object only
    # all() --
    # filter()
    # filter().values()

    # obj = User.objects.filter(phone=7400330074)

    # permission1 = request.user.get_group_permissions()
    # permission2 = request.user.get_all_permissions()   # Get the user's permissions, including group permissions
    # permission3 = request.user.get_user_permissions()    # Get the user's permissions directly
    return render(request, 'homepage.html', {'data': q, 'data1': p})


@login_required(login_url="/accounts/login/")
# @allowed_role_users(allowed_roles='1001')
@permission_required('Doctor_dashboard')
def doctor_dashboard(request):
    if request.user.is_authenticated:
        user = request.user
        return render(request, 'doctor_dashboard.html')


@login_required(login_url="/accounts/login/")
def med_prof_onboarding(request):
    return render(request, 'Medical-Professional-Onboarding.html')


@login_required(login_url="/accounts/login/")
def doctor_consultation(request):
    return render(request, 'doctor_consultation.html')


def speech_to_text(request):
    return render(request, 'speech-to-text.html')
