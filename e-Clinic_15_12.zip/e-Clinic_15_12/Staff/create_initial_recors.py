from django.contrib.auth.hashers import make_password
from CustomAuth.models import ProfessionalType, User
from allauth.socialaccount.models import SocialApp
from CustomAuth.models_grp_role import MstMenuItem, MstRole, MstRoleMenuItem, MstGroup
from Clinic.models.clinic import MstFlag


def create_admin():
    try:
        professions = ['Admin', 'Patient', 'Doctor', 'Front-Desk']
        for i in professions:
            po = ProfessionalType(name=i)
            po.save()
        p = ProfessionalType.objects.get(name='Admin')

        phone = 8888888888
        pa = 'adminadmin'
        password = make_password(pa)
        email = 'admin@dnits.com'

        user = User(profession=p, phone=phone, password=password, email=email, is_superuser=True, is_staff=True)
        user.save()

        s = SocialApp(
            provider='google',
            name='Google SSO',
            client_id='341096323111-gls9q9l55dthp0bb1rne0kl3o3q4fah5.apps.googleusercontent.com',
            secret='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',
            settings='{}')
        s.save()
    except:
        pass


def insert_mst_records(request):
    # ######## MST-Flag Entries: ------
    mst_data = [[1, 'SpecializationType', 'Anaesthesia', 'Anaesthesia'],
                [2, 'SpecializationType', 'BAMS', 'BAMS'],
                [3, 'SpecializationType', 'Cardiology', 'Cardiology'],
                [4, 'SpecializationType', 'Dentist/BDS', 'Dentist/BDS'],
                [5, 'SpecializationType', 'Diabetologist', 'Diabetologist'],
                [6, 'SpecializationType', 'Dietician', 'Dietician'],
                [7, 'SpecializationType', 'Endocrinology', 'Endocrinology'],
                [8, 'SpecializationType', 'ENT', 'ENT'],
                [9, 'SpecializationType', 'Gastroenterologist', 'Gastroenterologist'],
                [10, 'SpecializationType', 'General physician', 'General physician'],
                [11, 'SpecializationType', 'General surgeon', 'General surgeon'],
                [12, 'SpecializationType', 'MDS', 'MDS'],
                [13, 'SpecializationType', 'Medicine', 'Medicine'],
                [14, 'SpecializationType', 'Neurology', 'Neurology'],
                [15, 'SpecializationType', 'Obstetrician/ Gynaecologist', 'Obstetrician/ Gynaecologist'],
                [16, 'SpecializationType', 'Ophthalmology', 'Ophthalmology'],
                [17, 'SpecializationType', 'Paediatrics', 'Paediatrics'],
                [18, 'SpecializationType', 'Psychiatry', 'Psychiatry'],
                [19, 'SpecializationType', 'Psychologist', 'Psychologist'],
                [20, 'SpecializationType', 'Pulmonology', 'Pulmonology'],
                [21, 'SpecializationType', 'Rheumatologist/Immunologist', 'Rheumatologist/Immunologist'],
                [22, 'SpecializationType', 'Geriatric medicine', 'Geriatric medicine'],
                [23, 'SpecializationType', 'Urologist', 'Urologist'],
                [24, 'SpecializationType', 'Paediatric endocrinologist', 'Paediatric endocrinologist'],
                [25, 'SpecializationType', 'Oncologist', 'Oncologist'],
                [26, 'SpecializationType', 'Physiotherapist', 'Physiotherapist'],
                [27, 'SpecializationType', 'MD ayurveda', 'MD ayurveda'],
                [28, 'SpecializationType', 'IVF specialist', 'IVF specialist'],
                [29, 'SpecializationType', 'Emergency medicine', 'Emergency medicine'],
                [30, 'SpecializationType', 'Haematologist', 'Haematologist'],
                [31, 'SpecializationType', 'Orthopaedician', 'Orthopaedician'],
                [32, 'Certifications', 'License', 'License'],
                [33, 'HealthProfessionalDocumentType', 'State Medical Council Registration', 'Registration'],
                [34, 'HealthProfessionalDocumentType', 'Healthcare Professional Registry', 'HPR'],
                [35, 'HealthProfessionalDocumentType', 'No Objection Certificate', 'No Objection Certificate'],
                [36, 'Certifications', 'Internship Completion Certificate', 'Internship Certificate'],
                [37, 'HealthProfessionalDocumentType', 'Aadhar', 'Aadhar'],
                [38, 'HealthProfessionalDocumentType', 'Marksheet', 'MBBS Degree'],
                [39, 'HealthProfessionalDocumentType', 'Digital Signature', 'Digital Signature'],
                [40, 'HealthProfessionalDocumentType', 'PAN Card', 'PAN Card'],
                [41, 'HealthProfessionalDocumentType', 'Others', 'Others'],
                [42, 'NurseType', 'Registered Auxilliary Nurse Midwife', 'Registered Auxilliary Nurse Midwife'],
                [43, 'NurseType', 'Registered Nurse and Registered Midwife', 'Registered Nurse and Registered Midwife'],
                [44, 'NurseType', 'Registered Nurse', 'Registered Nurse'],
                [45, 'NurseType', 'Registered Lady Health Visitor', 'Registered Lady Health Visitor'],
                [46, 'EducationType', 'X', 'X'],
                [47, 'EducationType', 'XII', 'XII'],
                [48, 'EducationType', 'UG', 'UG'],
                [49, 'EducationType', 'PG', 'PG'],
                [50, 'EducationType', 'Others', 'Others'],
                [51, 'Certifications', 'Others', 'Others'],
                [52, 'FranchiseType', 'COCO', 'COCO'],
                [53, 'FranchiseType', 'COFO', 'COFO'],
                [54, 'FranchiseType', 'FOCO', 'FOCO'],
                [55, 'FranchiseType', 'FOFO', 'FOFO'],
                [56, 'ClinicType', 'InPatient', 'InPatient'],
                [57, 'ClinicType', 'Hospital', 'Hospital'],
                [58, 'ClinicType', 'OutPatient', 'OutPatient'],
                [59, 'CenterType', 'InPatient', 'InPatient'],
                [60, 'CenterType', 'Hospital', 'Hospital'],
                [61, 'CenterType', 'OutPatient', 'OutPatient'],
                [62, 'CenterMode', 'Physical', 'Physical'],
                [63, 'CenterMode', 'Virtual', 'Virtual'],
                [64, 'CenterMode', 'Hybrid', 'Hybrid'],
                [65, 'ClinicSubType', 'Physician', 'Physician'],
                [66, 'ClinicSubType', 'Specialist', 'Specialist'],
                [67, 'ClinicSubType', 'Dental', 'Dental'],
                [68, 'ClinicSubType', 'Psychiatric', 'Psychiatric'],
                [69, 'ClinicSubType', 'Pediatric', 'Pediatric'],
                [70, 'ClinicSubType', 'Therapist', 'Therapist'],
                [71, 'ClinicSubType', 'Blood', 'Blood'],
                [72, 'ClinicSubType', 'Urine', 'Urine'],
                [73, 'ClinicSubType', 'Stool', 'Stool'],
                [74, 'ClinicSubType', 'Imaging', 'Imaging'],
                [75, 'ClinicSubType', 'Genetic', 'Genetic'],
                [76, 'ClinicSubType', 'Biopsy', 'Biopsy'],
                [77, 'ClinicSubType', 'Surgical', 'Surgical'],
                [78, 'ClinicSubType', 'NonSurgical', 'NonSurgical'],
                [79, 'ClinicSubType', 'Online', 'Online'],
                [80, 'ClinicSubType', 'Offline with Home Delivery', 'OfflinewithHomeDelivery'],
                [81, 'ClinicSubType', 'Offline without Home Delivery', 'OfflinewithoutHomeDelivery'],
                [82, 'ClinicSubType', 'HomeCare', 'HomeCare'],
                [83, 'ClinicSubType', 'Hospital', 'Hospital'],
                [84, 'ClinicDocumentType', 'License', 'License'],
                [85, 'ClinicDocumentType', 'No Objection Certificate', 'No Objection Certificate']]

    for i in range(len(mst_data)):
        #print(f'{i} : ', mst_data[i])
        mst_flag = MstFlag(FlagID=mst_data[i][0],
                           FlagName=mst_data[i][1],
                           FlagValue=mst_data[i][2],
                           FlagDesc=mst_data[i][3],
                           ActiveFlag='A',
                           CreatedBy=request.user.id,
                           UpdatedBy=request.user.id, )
        try:
            mst_flag.save()
        except:
            return None


def insert_menu_items():
    menu_item_list = [[1, 'Registration', '', 1, 1],
                      [2, 'PatientRegistration', '', 1, 1],
                      [3, 'Appointments', '', 3, 1],
                      [4, 'BookAppointment', '', 3, 1],
                      [5, 'RescheduleAppointment', '', 3, 1],
                      [6, 'CancelAppointment', '', 3, 1],
                      [7, 'BookHomeCareServices', '', 3, 1],
                      [8, 'BookTherapy', '', 3, 1],
                      [9, 'BookHospitalReferral', '', 3, 1],
                      [10, 'Payment', '', 10, 1],
                      [11, 'Consultation', '', 10, 1],
                      [12, 'Pathology', '', 10, 1],
                      [13, 'Procedure', '', 10, 1],
                      [14, 'Pharmacy', '', 10, 1],
                      [15, 'HomeCare', '', 10, 1],
                      [16, 'Others', '', 10, 1],
                      [17, 'Consultation', '', 17, 1],
                      [18, 'PreExamination', '', 17, 1],
                      [19, 'Write Prescription', '', 17, 1],
                      [20, 'ConductLabTest', '', 17, 1],
                      [21, 'GenerateLabReports', '', 17, 1],
                      [22, 'ConductProcedure', '', 17, 1],
                      [23, 'GenerateProcedurePrescription', '', 17, 1],
                      [24, 'ConductTherapySession', '', 17, 1],
                      [25, 'History', '', 25, 1],
                      [26, 'ViewPrescription', '', 25, 1],
                      [27, 'ViewReports', '', 25, 1],
                      [28, 'ViewProcedureNotes', '', 25, 1],
                      [29, 'ViewTherapyNotes', '', 25, 1],
                      [30, 'ViewInvoices', '', 25, 1],
                      [31, 'MasterScreens', '', 31, 1],
                      [32, 'FranchiseClinicStatus', '', 31, 1],
                      [33, 'FranchiseType', '', 31, 1],
                      [34, 'ClinicType', '', 31, 1],
                      [35, 'ClinicCentreType', '', 31, 1],
                      [36, 'ClinicCentreSubType', '', 31, 1],
                      [37, 'ClinicCentreMode', '', 31, 1],
                      [38, 'AppointmentBookingType', '', 31, 1],
                      [39, 'ConsultationType', '', 31, 1],
                      [40, 'AppointmentBookingStatusType', '', 31, 1],
                      [41, 'SlotStatusType', '', 31, 1],
                      [42, 'PaymentStatus', '', 31, 1],
                      [43, 'PaymentSourceType', '', 31, 1],
                      [44, 'PaymentType', '', 31, 1],
                      [45, 'WalletPaymentType', '', 31, 1],
                      [46, 'ProcedureType', '', 31, 1],
                      [47, 'SurgicalProcedureType', '', 31, 1],
                      [48, 'NonSurgicalProcedureType', '', 31, 1],
                      [49, 'LeaveType', '', 31, 1],
                      [50, 'LeaveStatus', '', 31, 1],
                      [51, 'HealthProfessionalDocumentType', '', 31, 1],
                      [52, 'DocumentType', '', 31, 1],
                      [53, 'PathologyLabType', '', 31, 1],
                      [54, 'ProcedureCentreType', '', 31, 1],
                      [55, 'TherapyCentreType', '', 31, 1],
                      [56, 'PharmacyType', '', 31, 1],
                      [57, 'HomeCareCentreType', '', 31, 1],
                      [58, 'MedicineType', '', 31, 1],
                      [59, 'EducationType', '', 31, 1],
                      [60, 'SpecializationType', '', 31, 1],
                      [61, 'CertificationType', '', 31, 1],
                      [62, 'UniversityMaster', '', 31, 1],
                      [63, 'CollegeMaster', '', 31, 1],
                      [64, 'ProfessionalTypeMaster', '', 31, 1],
                      [65, 'ProfessionalSubTypeMaster', '', 31, 1],
                      [66, 'SpecialityMaster', '', 31, 1],
                      [67, 'PathologyTestTypeMaster', '', 31, 1],
                      [68, 'TherapyTypeMaster', '', 31, 1],
                      [69, 'TherapyActivityTypeMaster', '', 31, 1],
                      [70, 'PathologyLabTestMaster', '', 31, 1],
                      [71, 'LabTestReportParametersMaster', '', 31, 1],
                      [72, 'ProcedureMaster', '', 31, 1],
                      [73, 'ProcedureDetailsMaster', '', 31, 1],
                      [74, 'TherapyMaster', '', 31, 1],
                      [75, 'TherapyActivityMaster', '', 31, 1],
                      [76, 'PaymentHeadsMaster', '', 31, 1],
                      [77, 'MedicineGroupMaster', '', 31, 1],
                      [78, 'PharmaceuticalCompanyMaster', '', 31, 1],
                      [79, 'MedicineStrengthMaster', '', 31, 1],
                      [80, 'MedicineUnitsMaster', '', 31, 1],
                      [81, 'MedicineMaster', '', 31, 1],
                      [82, 'MedicineRatesMaster', '', 31, 1],
                      [83, 'Onboarding', '', 83, 1],
                      [84, 'HealthProfessional', '', 83, 1],
                      [85, 'HealthProfessionalClinic', '', 83, 1],
                      [86, 'Franchise', '', 83, 1],
                      [87, 'Clinic', '', 83, 1],
                      [88, 'ThirdPartyVendor', '', 83, 1],
                      [89, 'Approval', '', 89, 1],
                      [90, 'HealthProfessional', '', 89, 1],
                      [91, 'Franchise', '', 89, 1],
                      [92, 'Clinic', '', 89, 1],
                      [93, 'ThirdPartyVendor', '', 89, 1],
                      [94, 'Groups&Roles', '', 94, 1],
                      [95, 'Add-Edit-MenuItem', '', 94, 1],
                      [96, 'Add-Edit-Role', '', 94, 1],
                      [97, 'Add-Edit-Group', '', 94, 1],
                      [98, 'UserMaster', '', 94, 1],
                      [99, 'RateCard', '', 99, 1],
                      [100, 'Add-Edit-DoctorConsultationCharges', '', 99, 1],
                      [101, 'Add-Edit-TherapistConsultationCharges', '', 99, 1],
                      [102, 'Add-Edit-PathologyCharges', '', 99, 1],
                      [103, 'Add-Edit-ProcedureCharges', '', 99, 1],
                      [104, 'Add-Edit-TherapyCharges', '', 99, 1],
                      [105, 'Add-Edit-MedicineRates', '', 99, 1],
                      [106, 'MasterScreens', '', 106, 1],
                      [107, 'AdminUser', '', 106, 1],
                      [108, 'DoctorWallet', '', 106, 1],
                      [109, 'PatientWallet', '', 106, 1]]

    for i in range(len(menu_item_list)):
        #print(f'{i} : ', menu_item_list[i])
        MenuItemId = menu_item_list[i][0]
        MenuItemName = menu_item_list[i][1]
        MenuItemDesc = menu_item_list[i][2]
        MainMenuId = menu_item_list[i][3]
        ClinicId = menu_item_list[i][4]
        menu_items = MstMenuItem(
            MenuItemId=MenuItemId,
            MenuItemName=MenuItemName,
            MenuItemDesc=MenuItemDesc,
            MainMenuId=MainMenuId,
            WebpageLink='#',
            ClinicId=ClinicId,
            ActiveFlag='A',
            CreatedBy=1,
            UpdatedBy=1)
        try:
            menu_items.save()
        except:
            return None


def update_menu_weblinks():
    menu = MstMenuItem.objects.get(MenuItemName='BookAppointment')
    menu.WebpageLink = 'Patient/book-appointment/'
    menu.save()
    menu = MstMenuItem.objects.get(MenuItemName='PatientRegistration')
    menu.WebpageLink = 'Patient/patient-registration/'
    menu.save()


def create_role():
    role_list = [[1, 'Registration'],
                 [2, 'Appointments'],
                 [3, 'Payment'],
                 [4, 'Consultation'],
                 [5, 'History'],
                 [6, 'MasterScreens'],
                 [7, 'Onboarding'],
                 [8, 'Approval'],
                 [9, 'Groups&Roles'],
                 [10, 'RateCard'],
                 ]
    for i in range(len(role_list)):
        #print(f'{i} : ', role_list[i])
        role = MstRole(RoleId=role_list[i][0],
                       RoleName=role_list[i][1],
                       RoleDesc=role_list[i][1],
                       ClinicId=1,
                       ActiveFlag='A',
                       CreatedBy=1,
                       UpdatedBy=1)
        try:
            role.save()
        except:
            pass


def create_role_menu():
    role_menu_list = [[1, 1, 1],
                      [2, 3, 2],
                      [3, 10, 3],
                      [4, 17, 4],
                      [5, 25, 5],
                      [6, 31, 6],
                      [7, 83, 7],
                      [8, 89, 8],
                      [9, 94, 9],
                      [10, 99, 10],
                      [11, 106, 11]]

    for i in range(len(role_menu_list)):
        #print(f'{i} : ', role_menu_list[i])
        role_menu = MstRoleMenuItem(RoleMenuItemId=role_menu_list[i][0],
                                    MenuItemIdFK=MstMenuItem.objects.get(MenuItemId=role_menu_list[i][1]),
                                    RoleIdFK=MstRole.objects.get(RoleId=role_menu_list[i][2]))
        try:
            #print("..............1.", MstMenuItem.objects.get(MenuItemId=role_menu_list[i][1]))
            #print("..............2.", MstRole.objects.get(RoleId=role_menu_list[i][2]))
            role_menu.save()
        except:
            return None


def create_group():
    group = ['Admin', 'Patient', 'Doctor', 'Front-Desk']
    for i in range(len(group)):
        MstGroup.objects.create(GroupId=i + 1, GroupName=group[i], GroupDesc=group[i], ClinicId=1, ActiveFlag='A',
                                UpdatedBy=1, CreatedBy=1)
