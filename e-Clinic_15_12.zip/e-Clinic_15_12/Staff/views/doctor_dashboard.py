from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required
from CustomAuth.models import ProfessionalType, User
from CustomAuth.utility import get_user_menu
from Staff.models.doctor import TblDoctorSlot
from django.db.models import Q
from django.utils import timezone
from django.core.serializers import serialize
from datetime import date, time
from Patient.models.appointment import Appointment
import json
from Patient.models.patient import MstPatient
from django.contrib import messages
from django.db import transaction
from Staff.models.professional_Onboarding import MstHealthProfessional


def serialize_date(obj):
    if isinstance(obj, (date, time)):
        return obj.isoformat()


@login_required(login_url="/accounts/login/")
# @permission_required('Doctor_dashboard')
def doctor_dashboard(request):
    menu_items = None
    if request.user.is_authenticated:
        menu_items = get_user_menu(request)
    if request.user.is_authenticated:
        user = request.user.id
        #print(user)
        if request.method == 'GET':
            obj = list(TblDoctorSlot.objects.filter(Q(Status='Available') & Q(UserIdFK=user)).values())
            slot_data_json = json.dumps(obj, default=serialize_date)

            appointment = Appointment.objects.filter(Q(Active='A') & Q(Date=timezone.now().date()) & Q(UserIDFK=user))
            upcoming = Appointment.objects.filter(Q(Active='A') & ~Q(Date=timezone.now().date()) & Q(UserIDFK=user))
            #print("appointment--------", appointment)
            #print("appointment--------", upcoming)
            return render(request, 'doctor_dashboard.html',
                          {'obj': slot_data_json, 'appn': appointment, 'upcoming': upcoming, 'menu_items': menu_items})
        else:
            try:
                with transaction.atomic():
                    slotid = request.POST.get('flexRadioDefault')
                    timesget = request.POST.get('newtime')
                    #print(timesget)

                    ##print(slotid)
                    docslot = TblDoctorSlot.objects.filter(DoctorSlotIdPK=slotid).update(Status='Booked')

                    appoinmnt = Appointment(
                        AppointmentIDPK=request.POST.get('appid'),
                        Date=request.POST.get('ondate'),
                        Time=timesget,
                        Active='A',
                        BookingType=request.POST.get('bookingtype'),
                        AppointmentType=request.POST.get('appointmenttype'),
                        AppointmentBy='ABC',

                        CenterType=request.POST.get('centertype'),
                        DoctorIDFK=MstHealthProfessional.objects.get(
                            MstHealthProfessionalIDPK=request.POST.get('doctoridfk')),

                        PatientIDFK=MstPatient.objects.get(RecordIDPK=int(request.POST.get('patientid'))),
                        SlotIDFK=TblDoctorSlot.objects.get(DoctorSlotIdPK=request.POST.get('flexRadioDefault')),
                        UserIDFK=request.user,
                        CreationDateTime='2023-12-13 12:20:45.197238+05:30'
                    )
                    appoinmnt.save()
                    messages.info(request, 'Reschedule Successfully!')
                    return redirect('doctor_dashboard')
            except Exception as e:
                messages.warning(request, "Not Submitted")

                return redirect('doctor_dashboard')
