

def front_desk_dashboard(request):
    return None