from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required
from CustomAuth.utility import get_user_menu
from Staff.create_initial_recors import create_admin, insert_mst_records, update_menu_weblinks, insert_menu_items, create_role, create_role_menu, create_group


def homepage(request):
    create_admin()
    insert_mst_records(request)
    insert_menu_items()
    # update_menu_weblinks()
    # create_role()
    # create_role_menu()
    # create_group()

    menu_items = None
    if request.user.is_authenticated:
        menu_items = get_user_menu(request)
    return render(request, 'homepage.html', {'menu_items': menu_items})


@login_required(login_url="/accounts/login/")
# @allowed_role_users(allowed_roles='1001')
# @permission_required('Doctor_dashboard')
def doctor_dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'dashboard.html')


# def speech_to_text(request):
#     return render(request, 'speech-to-text.html')
