from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required
from CustomAuth.utility import get_user_menu
from Staff.create_initial_recors import create_admin, insert_mst_records, update_menu_weblinks, insert_menu_items, create_role, create_role_menu, create_group
from CustomAuth.utility import get_user_menu


def admin_dashboard(request):
    menu_items = None
    if request.user.is_authenticated:
        menu_items = get_user_menu(request)
    return render(request, 'admin_dashboard.html', {'menu_items': menu_items})
