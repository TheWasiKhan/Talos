from django.contrib import admin
# from CustomAuth.models import ProfessionalType
from Staff.models.doctor import TblDoctorSlot, TblDoctorSchedule
from Staff.models import consultation
# from Staff.models.menu_items import Menu, SubMenu
from Staff.models.professional_Onboarding import HealthProfessionalPersonalDetails, HealthProfessionalEducationDetails, HealthProfessionalExperienceDetails, HealthProfessionalBankDetails, HealthProfessionalCertificationDetails, HealthProfessionalDocumentLinks, MstUniversity, MstCollege, MstHealthProfessional


class AdminUser(admin.ModelAdmin):
    list_display = []


class AdminProfessionalType(admin.ModelAdmin):
    list_display = ['id', 'name']


class AdminSlot(admin.ModelAdmin):
    list_display = []


class AdminDoctor(admin.ModelAdmin):
    list_display = []


class AdminMenu(admin.ModelAdmin):
    list_display = ['name']


class AdminSubMenu(admin.ModelAdmin):
    list_display = ['name']


class AdminTblDoctorSchedule(admin.ModelAdmin):
    list_display = ['Day', 'StartDate', 'EndDate', 'SlotDuration', 'NoofSlots', 'StartTime']


class AdminTblDoctorSlot(admin.ModelAdmin):
    list_display = ['SlotDate', 'Day', 'StartTime', 'EndTime', 'Status']


# admin.site.register(ProfessionalType, AdminProfessionalType)
# admin.site.register(ClinicProfessional, AdminClinicProfessional)

admin.site.register(TblDoctorSchedule, AdminTblDoctorSchedule)
admin.site.register(TblDoctorSlot, AdminTblDoctorSlot)
admin.site.register(HealthProfessionalPersonalDetails)
admin.site.register(HealthProfessionalEducationDetails)
admin.site.register(HealthProfessionalExperienceDetails)
admin.site.register(HealthProfessionalCertificationDetails)
admin.site.register(HealthProfessionalDocumentLinks)
admin.site.register(HealthProfessionalBankDetails)
admin.site.register(MstUniversity)
admin.site.register(MstCollege)
admin.site.register(MstHealthProfessional)
admin.site.register(consultation.Vitals)
admin.site.register(consultation.Symptoms)
admin.site.register(consultation.PreExisting)
admin.site.register(consultation.Diagnosis)
admin.site.register(consultation.Document)
admin.site.register(consultation.Prescription)
# admin.site.register(Menu, AdminMenu)
# admin.site.register(SubMenu, AdminSubMenu)

admin.site.site_header = "eSwasthalya e-Clinic"
admin.site.site_title = "e-Clinic"
