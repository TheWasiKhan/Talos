from django.urls import path
from Clinic.views import clinic_onboarding, clinic_dashboard

urlpatterns = [
    path('Clinic-onboarding/', clinic_onboarding.clinic_onboarding, name='clinic_onboarding'),
    path('Clinic-Dashboard/', clinic_dashboard.clinic_dashboard, name='clinic_dashboard'),
    ]