from django.shortcuts import render, redirect
from Clinic.models.clinic import Mst_Clinic, Mst_Clinic_BankDetails, Mst_Clinic_Contact, Mst_Clinic_Address, \
    Mst_Clinic_Center, Mst_Clinic_Document, MstFlag, Tbl_ThirdPartyCollab
from CustomAuth.utility import get_user_menu


def clinic_onboarding(request):
    menu_items = None
    if request.user.is_authenticated:
        menu_items = get_user_menu(request)
    if request.method == 'POST':
        Clinic = Mst_Clinic.objects.create(
            Clinic_name=request.POST.get('clinic_name'),
            UserIDFK=request.user,
            Franchise_type=request.POST.get('franchiseType'),
            Clinic_type=request.POST.get('clinicType'),
            Clinic_description=request.POST.get('clinic_description'),
        )

        for i in range(len(request.POST.getlist('Contact_Name'))):
            Mst_Clinic_Contact.objects.create(
                Clinic=Clinic,
                Name=request.POST.getlist('Contact_Name')[i],
                Phone_no=request.POST.getlist('Phone_No')[i],
                Email_id=request.POST.getlist('Email_ID')[i],
                Designation=request.POST.getlist('Designation')[i],
            )

        Mst_Clinic_Address.objects.create(
            Clinic=Clinic,
            Address_line1=request.POST.get('address_Line1'),
            Address_line2=request.POST.get('address_Line2'),
            Pin_code=request.POST.get('PinCode'),
            City=request.POST.get('city'),
            State=request.POST.get('state'),
            Country=request.POST.get('country'),
        )

        for i in range(len(request.POST.getlist('centerType'))):
            Mst_Clinic_Center.objects.create(
                Clinic=Clinic,
                Center_type=request.POST.getlist('centerType')[i],
                Center_mode=request.POST.getlist('centerMode')[i],
                Clinic_centre_sub_type=request.POST.getlist('clinicCentreSubType')[i],
                Contact_name_center=request.POST.getlist('Contact_Name_center')[i],
                Phone_no_center=request.POST.getlist('Phone_No_center')[i],
                Email_id_center=request.POST.getlist('Email_ID_center')[i],
                Third_party_collab=request.POST.getlist('thirdPartyCollab')[i],
            )
        document_files = request.FILES.getlist('Upload_File')
        for i in range(len(request.POST.getlist('Upload_Document_name'))):
            if i < len(document_files):  # Check if the index is within the range of files
                Mst_Clinic_Document.objects.create(
                    Clinic=Clinic,
                    Document_name=request.POST.getlist('Upload_Document_name')[i],
                    Document_type=request.POST.getlist('Upload_Doc_Type')[i],
                    Document_description=request.POST.getlist('Upload_Description')[i],
                    Document_remark=request.POST.getlist('Upload_Remark')[i],
                    Document_file=document_files[i],
                )

        Mst_Clinic_BankDetails.objects.create(
            Clinic=Clinic,
            AccountType=request.POST.get('accounttype'),
            HolderName=request.POST.get('holdername'),
            AccountNumber=request.POST.get('accnumber'),
            IFSCcode=request.POST.get('ifsccode'),
            BankName=request.POST.get('bankname'),
            BranchName=request.POST.get('branchname'),
        )

        return redirect('clinic_onboarding')

    elif request.method == 'GET':

        try:
            clinic_details = Mst_Clinic.objects.get(UserIDFK=request.user)
            contact_details = Mst_Clinic_Contact.get(Clinic=clinic_details.Clinic_id)
        except:
            clinic_details = {}
        context = {'franchiseType': MstFlag.objects.filter(FlagName='FranchiseType'),
                   'clinicType': MstFlag.objects.filter(FlagName='ClinicType'),
                   'centerType': MstFlag.objects.filter(FlagName='CenterType'),
                   'centerMode': MstFlag.objects.filter(FlagName='CenterMode'),
                   'clinicCentreSubType': MstFlag.objects.filter(FlagName='ClinicSubType'),
                   'thirdPartyCollab': Tbl_ThirdPartyCollab.objects.all(),
                   'Upload_Doc_Type': MstFlag.objects.filter(FlagName='ClinicDocumentType'),
                   'clinic_details': clinic_details,
                   'menu_items': menu_items}
        return render(request, 'clinic_onboarding.html', context)
