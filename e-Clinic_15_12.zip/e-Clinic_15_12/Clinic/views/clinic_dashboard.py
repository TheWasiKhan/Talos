from django.shortcuts import render
from django.http import HttpResponse
from Clinic.models.clinic import Mst_Clinic, Mst_Clinic_BankDetails, Mst_Clinic_Contact, Mst_Clinic_Address, \
    Mst_Clinic_Center, Mst_Clinic_Document, Tbl_ThirdPartyCollab
from Clinic.models.clinic import MstFlag
from CustomAuth.utility import get_user_menu


def clinic_dashboard(request):
    menu_items = None
    if request.user.is_authenticated:
        menu_items = get_user_menu(request)
    if request.method == 'POST':
        pass
    else:
        return render(request, 'clinic_dashboard.html', {'menu_items': menu_items})
