from django.db import models

from CustomAuth.models import User


class Mst_Clinic(models.Model):
    Clinic_id = models.AutoField(primary_key=True)
    UserIDFK = models.ForeignKey(User, on_delete=models.CASCADE)
    Clinic_name = models.CharField(max_length=255)
    Franchise_type = models.CharField(max_length=255)
    Clinic_type = models.CharField(max_length=255)
    Clinic_description = models.TextField()
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)

    @staticmethod
    def get_clinic_id():
        return Mst_Clinic.objects.get(Clinic_id=1)

    def __str__(self):
        return self.Clinic_name


class Mst_Clinic_Contact(models.Model):
    Contact_id = models.AutoField(primary_key=True)
    Clinic = models.ForeignKey(Mst_Clinic, on_delete=models.CASCADE)
    Name = models.CharField(max_length=255)
    Phone_no = models.CharField(max_length=15)
    Email_id = models.EmailField()
    Designation = models.CharField(max_length=255)
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)


class Mst_Clinic_Address(models.Model):
    Address_id = models.AutoField(primary_key=True)
    Clinic = models.OneToOneField(Mst_Clinic, on_delete=models.CASCADE)
    Address_line1 = models.CharField(max_length=255)
    Address_line2 = models.CharField(max_length=255, blank=True, null=True)
    Pin_code = models.CharField(max_length=10)
    City = models.CharField(max_length=255)
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)
    State = models.CharField(max_length=255)
    Country = models.CharField(max_length=255)


class Mst_Clinic_Center(models.Model):
    Address_id = models.AutoField(primary_key=True)
    Clinic = models.ForeignKey(Mst_Clinic, on_delete=models.CASCADE)
    Center_type = models.CharField(max_length=255)
    Center_mode = models.CharField(max_length=255)
    Clinic_centre_sub_type = models.CharField(max_length=255)
    Contact_name_center = models.CharField(max_length=255)
    Phone_no_center = models.CharField(max_length=15)
    Email_id_center = models.EmailField()
    Third_party_collab = models.CharField(max_length=255)
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)


class Mst_Clinic_Document(models.Model):
    Document_id = models.AutoField(primary_key=True)
    Clinic = models.ForeignKey(Mst_Clinic, on_delete=models.CASCADE)
    Document_name = models.CharField(max_length=255)
    Document_type = models.CharField(max_length=255)
    Document_description = models.TextField()
    Document_remark = models.TextField()
    Document_file = models.FileField(upload_to='uploads/')
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)


class Mst_Clinic_BankDetails(models.Model):
    BankDetails_Id = models.AutoField(primary_key=True)
    Clinic = models.ForeignKey(Mst_Clinic, on_delete=models.CASCADE)
    ACCOUNT_TYPES = [
        ('Saving', 'Saving'),
        ('Current', 'Current'),
    ]
    AccountType = models.CharField(max_length=10, choices=ACCOUNT_TYPES)
    HolderName = models.CharField(max_length=255)
    AccountNumber = models.CharField(max_length=20)
    IFSCcode = models.CharField(max_length=20)
    BankName = models.CharField(max_length=255)
    BranchName = models.CharField(max_length=255)
    Active = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=8)
    UpdatedBy = models.CharField(max_length=8)
    CreationDateTime = models.DateTimeField(auto_now_add=True)
    UpdationDateTime = models.DateTimeField(auto_now=True)


class Tbl_ThirdPartyCollab(models.Model):
    ThirdPartyId = models.AutoField(primary_key=True)
    ThirdPartyName = models.CharField(max_length=100)
    ThirdPartyValue = models.CharField(max_length=100)
    ThirdPartyDesc = models.CharField(max_length=100)
    ActiveFlag = models.CharField(max_length=3, default=True)
    CreatedBy = models.CharField(max_length=15)
    UpdatedBy = models.CharField(max_length=15)
    CreationDate = models.DateTimeField(auto_now_add=True)
    UpdationDate = models.DateTimeField(auto_now=True)


class MstFlag(models.Model):
    FlagID = models.IntegerField(primary_key=True)
    FlagName = models.CharField(max_length=100)
    FlagValue = models.CharField(max_length=100)
    FlagDesc = models.CharField(max_length=100)
    ActiveFlag = models.CharField(max_length=3, default='A')
    CreatedBy = models.CharField(max_length=15)
    UpdatedBy = models.CharField(max_length=15)
    CreationDate = models.DateTimeField(auto_now_add=True)
    UpdationDate = models.DateTimeField(auto_now=True)