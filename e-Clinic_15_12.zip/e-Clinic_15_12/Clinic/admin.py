from django.contrib import admin
from Clinic.models.clinic import Mst_Clinic, MstFlag

admin.site.register(Mst_Clinic)
admin.site.register(MstFlag)
